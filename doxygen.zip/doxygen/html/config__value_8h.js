var config__value_8h =
[
    [ "MAX_N_GT", "config__value_8h.html#a486663aa90115780beab9f9d39fa8973", null ],
    [ "MAX_TAG_NAME_LEN", "config__value_8h.html#ada71b9f258860d58a86ab220bfce6bf4", null ],
    [ "MAX_TAGS", "config__value_8h.html#aa653c0eca99802a09fd9560f28a9b1c1", null ],
    [ "N_BYTES", "config__value_8h.html#a470399f7b67e59b1cd04ab17e03c96d1", null ],
    [ "CAN_MODE", "config__value_8h.html#ac0d6cdda2cf4abb51116b86bc99acf99", [
      [ "RECEVE_ONLY", "config__value_8h.html#ac0d6cdda2cf4abb51116b86bc99acf99a7d47d78204fba2e07bda4e65594ff332", null ],
      [ "SEND_ONLY", "config__value_8h.html#ac0d6cdda2cf4abb51116b86bc99acf99ad5ec70c56183ea13f8a0c16a3708a23e", null ],
      [ "SEND_AND_RECEVE", "config__value_8h.html#ac0d6cdda2cf4abb51116b86bc99acf99ac4e66207fce47c294e4aaab76000c9ce", null ]
    ] ],
    [ "CAN_TG_STATUE", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947f", [
      [ "CAN_TG_ERROR_NOT_ENOUNG_SPACE_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa4add2030061ed8081fd69bbc7961b88e", null ],
      [ "CAN_TG_SUCCESS", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa08e8f2b1a9c883eec6fdc9f76bad06e3", null ],
      [ "CAN_TG_ERROR_TAG_NOT_FOUND_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947faefecc0d5f9f8d279aeeac67967a54040", null ],
      [ "CAN_TG_ERROR_TAG_NAME_TO_BIGS_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa0766008cbf1754ab42a2e4995b18e1d2", null ],
      [ "CAN_TG_ERROR_TOO_MAY_TAGS_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa2d5a4a6abf40a9b845d30b4927cc8321", null ],
      [ "CAN_TG_ERROR_SIZE_VALUE_INVALIDE_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa1f64facc77e1738f2ed16fae7f38140f", null ],
      [ "CAN_TG_ERROR_NAME_ALREADY_USE_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fadb8a1b35ff867562e04d179242c150f2", null ],
      [ "CAN_TG_ERROR_SUBDIVISION_FAIL_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947faf1069aa607410cd4bdeb9609f6b03a6b", null ],
      [ "CAN_TG_ERROR_TAG_NAME_INVALIDE_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947faa30bc0e8a501b29dbf6d3b5c3e4fe6f9", null ],
      [ "CAN_TG_ERROR_NULL_POINTOR_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa8f8b6e84f2b232e0ed2995b7afbd0c44", null ],
      [ "CAN_TG_ERROR_TRY_TO_FIND_END_CARACTER_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fab194d19ed0940cb65b5c625b913aaa40", null ],
      [ "CAN_TG_ERROR_INTERNAL_CORUPTION_", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fa4ec6d89f60bf1ee862d7b94bed822768", null ],
      [ "CAN_TG_ERROR_VALUE_TO_BIG", "config__value_8h.html#af59c8e96bb2966b590726fc2d285947fab1cfc87a8731dfcbc6e986a1b81115ac", null ]
    ] ],
    [ "CAN_TG_ERROR_INTERNAL_CORUPTION", "config__value_8h.html#a7f995285b1ed198ba4c10528ef66b8fe", null ],
    [ "CAN_TG_ERROR_NAME_ALREADY_USE", "config__value_8h.html#a18061c1ca5fc2e5ab20fa7bc8dbe81d6", null ],
    [ "CAN_TG_ERROR_NOT_ENOUNG_SPACE", "config__value_8h.html#a6ac7074ca0f94196368735678d92c7b8", null ],
    [ "CAN_TG_ERROR_NULL_POINTOR", "config__value_8h.html#ada864c858133fa1c52368562add7d64e", null ],
    [ "CAN_TG_ERROR_SIZE_VALUE_INVALIDE", "config__value_8h.html#a73337c3ada0009e763ea5af164e25d70", null ],
    [ "CAN_TG_ERROR_SUBDIVISION_FAIL", "config__value_8h.html#acb2aafd99394462e0f83f05673be52a9", null ],
    [ "CAN_TG_ERROR_TAG_NAME_INVALIDE", "config__value_8h.html#a49d547279f99d23ff36998f3874d3c5a", null ],
    [ "CAN_TG_ERROR_TAG_NAME_TO_BIGS", "config__value_8h.html#af68b72a5b65a0168415d1363dc09a0a6", null ],
    [ "CAN_TG_ERROR_TAG_NOT_FOUND", "config__value_8h.html#ab0c8b9c7e93d137cd8956e4c391a0f4c", null ],
    [ "CAN_TG_ERROR_TOO_MAY_TAGS", "config__value_8h.html#a1e77443066dccbc42ef0acdd0f597c07", null ],
    [ "CAN_TG_ERROR_TRY_TO_FIND_END_CARACTER", "config__value_8h.html#a3cf459060e0c412c5908438afc160d9f", null ],
    [ "SUCCES", "config__value_8h.html#afb042b80a35ed7a692f9001589ddf8c6", null ],
    [ "SUCCES_TO_SET", "config__value_8h.html#af9a28b199e843773aefbb1e1bcf50559", null ]
];